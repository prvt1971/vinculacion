<?php
    $USER = "root";
    // $USER = "prvtonen_pvaldestamayo"; //Bluehost
    $PASSWORD = "";
    //$PASSWORD = "Cleopatra71*/MySql"; //bluehost
    $HOST="localhost";
    //$HOST="50.87.220.245"; //bluehost
    $PATH = "H:/Mi unidad/www/titulacion";
    //$PATH = "C:/xampp/htdocs/titulacion";
    $W3DIRECTORY = "http://localhost/titulacion";
    $DBNAME = "titulacion";
    //$DBNAME = "prvtonen_titulacion"; //bluehost
?>
