<?php
 $USER = "root";
 $PASSWORD = "";
 $HOST="localhost";
 $W3DIRECTORY = "C:/xampp/htdocs/titulacion";
 $DBNAME = "titulacion";
?>
