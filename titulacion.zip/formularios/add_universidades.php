<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/titulacion/css/bootstrap.min.css">
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>
    <form class="form-floating" action=""></form>
        <div class="row"> 
            <div class="col-md-6">
                    <div class="form-floating mb-1">
                        <input type="text" class="form-control" id="Nombre" placeholder="Universidad ...">
                        <label for="Nombre">Nombre:</label>
                    </div>
            </div>
            <div class="col-md-6">
                <div class="form-floating mb-1">
                    <input type="text" class="form-control" id="email" placeholder="cuenta@...">
                    <label for="email">Correo:</label>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                    <div class="form-floating mb-1">
                        <input type="text" class="form-control" id="URL" placeholder="http:// ...">
                        <label for="URL">URL:</label>
                    </div>			
            </div> 
            <div class="col-md-6">
                <div class="input-group form-floating">
                    <input type="file" class="form-control" id="Logotipo" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
                    <label for="Logotipo">Logotipo:</label>
                    <button class="btn btn-primary" type="button" id="inputGroupFileAddon04">Aplicar</button>
                </div>
            </div>

        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="form-floating">
                    <select class="form-select" id="floatingSelect" aria-label="Floating label select example">
                      <option selected>Rector sin asignar</option>
                      <option value="1">One</option>
                      <option value="2">Two</option>
                      <option value="3">Three</option>
                    </select>
                    <label for="floatingSelect">Rector:</label>
                </div>
            </div> 
            <div class="col-md-6 mb-3 aling-item-right">
                <div class="row">
                    <div class="col-md-6">

                    </div>
                    <div class="col-md-6">
                        <img src='imagenes/i1.png' alt = 'Salir'>
                    </div>
                </div>
                
            </div>    
        </div>
        <div class="row">
            <div class="col-md-6">
                
            </div> 
            <div class="col-md-6">
                <button type="button" class="btn btn-primary" action="Sube.php">Aceptar</button>
                <button type="button" class="btn btn-danger">Calcelar</button>
            </div>    
        </div>
        
    </form>
</body>
</html>

