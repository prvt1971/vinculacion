<?php
    $USER = "root";
    $PASSWORD = "";
    $HOST="localhost";
    $PATH = "C:/xampp/htdocs/titulacion";
    $W3DIRECTORY = "http://localhost/titulacion/";
    $DBNAME = "titulacion";
?>
