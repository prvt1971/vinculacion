<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>Subir archivo facultad</h1>
	<form action="sube.php" method="post" enctype="multipart/form-data">
		<input type="file" name="archivo">
		<br><br>
		<button>Subir Archivo</button>
	</form>
</body>
</html>