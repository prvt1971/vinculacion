<?PHP
	include_once("include.php");
	include_once($PATH."/libreria.php");
	session_start(['usuario']);
	if (isset($_GET['Accion'])){

	}else{
		session_unset();
	}
	
	if (isset($_SESSION['usuario']['privilegio'])){
			$Rol=$_SESSION['usuario']['privilegio'];
	}else{
		$Rol=0;
	}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>SGI-CEDIT </title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="bootstrap.bundle.min.js">
<link rel="stylesheet" href="css/misestilos.css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body>
<!-- Código para personalizar la barra de menú principal -->
<div id="BarraPrincipal">
	<?php 
		switch ($Rol){
			case 0:
				include("barras_navegacion/barra_principal.php");
				break;
			case 1:
				include("barras_navegacion/barra_admin.php");
				break;
			
		}	
	?>
</div>

<div  class="container">
	<div class="row">
		<div class="col-sm-3">
			<!-- <img src='imagenes/i1.png' alt = 'Salir'> -->
		</div>
		<div class="col-sm-6">
			<center><h3>SISTEMA INFORMATIZADO PARA LA GESTIÓN DE LA VINCULACIÓN CON LA SOCIEDAD</h3></center>
		</div>
		<div class="col-sm-3">
			<!-- <img src='imagenes/i2.jpg' alt = 'Salir'> -->
		</div>
	</div>
</div>
<!-- Contenedor principal -->
<div class="container">
	<div class="row">
		<div id="areaprincipal" class="col-sm-9 capa-principal">
			<div>
				<img src='imagenes/unesum.jpg' alt = 'Salir'>
			</div>	
		</div>
		<div id="Contenedor1" class="col-sm-3 d-flex justify-content-center align-items-center bg-primary">
			<div>
				<?php 
					if (isset($_GET['Accion'])){
						if ($_GET['Accion']==1){
							if ($_GET['Mostrar']==1){
								include("formularios/form_login.php");
							}else{
							}
						}else{
							include("mostrar_datos_usuario.php");
						}
					}else{
					}
				?>
			</div>
		</div>
	</div>
</div>
<script type="text/JavaScript">
	function Loguear(){
		document.getElementById("Contenedor1").innerHTML="<iframe src='formularios/form_login.php' frameborder='0'></iframe>"
	}
</script>
</body>
</html>
