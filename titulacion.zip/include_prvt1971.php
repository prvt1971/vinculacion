<?php
    $USER = "prvtonen_pvaldestamayo";
    $PASSWORD = "Cleopatra71*/MySql";
    $HOST="localhost";
    $PATH = "/home3/prvtonen";
    $W3DIRECTORY = "http://prvt1971.com/";
    $DBNAME = "prvtonen_titulacion";
?>
